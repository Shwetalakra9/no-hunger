<?php
// require_once './src/home.php';
header('Location: ./src/home.php');