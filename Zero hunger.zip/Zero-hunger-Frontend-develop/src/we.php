<div class="product-removal">
    <button class="remove-product">
       <span class="fa fa-times remove-icon"></span> <span class="remove">Remove</span>
    </button>
    </div>