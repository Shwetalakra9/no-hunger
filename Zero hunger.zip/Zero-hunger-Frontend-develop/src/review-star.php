<ul class="rating-stars">
					<li style="width:50%" class="stars-active"> 
						<i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i>
					</li>
					<li>
						<i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i> 
					</li>
				</ul>
        <small class="text-muted">34</small>
        


				<del class="price-old">$13.99</del>
				


				<!-- select dropdown -->
				<div class="col-lg col-sm col-md col-6 flex-grow-0">
		<div class="category-wrap dropdown d-inline-block float-md-right">
			<button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown"> 
				<i class="fa fa-bars"></i> All category 
			</button>
			<div class="dropdown-menu">
				<a class="dropdown-item" href="#">Protein </a>
				<a class="dropdown-item" href="#">Grains </a>
				<a class="dropdown-item" href="#">Produce</a>
				<a class="dropdown-item" href="#">Vegetable </a>
				<a class="dropdown-item" href="#">Oil </a>
				<a class="dropdown-item" href="#">Condiments </a> 
			</div>
		</div>  <!-- category-wrap.// -->
	</div> <!-- col.// -->