<form>
   <div class="form-group">
            <div class="input-group">
				<div class="input-group-prepend">
				    <span class="input-group-text"> <i class="fa fa-user"></i> </span>
				 </div>
				<input name="" class="form-control" placeholder="Username" type="text">
			</div> <!-- input-group.// -->
          </div> <!-- form-group// -->
          <div class="form-group">
            <div class="input-group">
				<div class="input-group-prepend">
				    <span class="input-group-text"> <i class="fa fa-lock"></i> </span>
				 </div>
				<input name="" class="form-control" placeholder="Password" type="password">
			</div> <!-- input-group.// -->
          </div> <!-- form-group// -->
          <div class="form-group"> 
            <label class="custom-control custom-checkbox"> <input type="checkbox" class="custom-control-input" checked=""> <div class="custom-control-label"> Remember </div> </label>
          </div> <!-- form-group form-check .// -->
          <div class="form-group">
              <button type="submit" class="btn btn-primary btn-block"> Login  </button>
          </div> <!-- form-group// -->    
         </form>
         
			<div class="alternative-login">
				<p class="text-center divider-line"><span class="">Or</span></p>
			<a href="#" class="btn btn-facebook btn-block mb-2"> <i class="fab fa-facebook-f"></i> &nbsp  Sign in with Facebook</a>
      	  <a href="#" class="btn btn-google btn-block mb-4"> <i class="fab fa-google"></i> &nbsp  Sign in with Google</a>
         </div>
         <div class="reg-fogotten">
           <a href="#"><span>Forgot password</span></a>  | 
           <a href="./register.php"><span>Register</span></a>
            
         </div>
         