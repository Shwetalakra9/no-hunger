
<!-- jQuery  -->
<script src="./vendor/js/jquery.min.js" type="text/javascript"></script>

<!-- Bootstrap4 files
<script src="../js/bootstrap.bundle.min.js" type="text/javascript"></script>
-->
<!-- custom javascript -->
<script src="./resources/js/component-ajax-request.js" type="text/javascript"></script>
