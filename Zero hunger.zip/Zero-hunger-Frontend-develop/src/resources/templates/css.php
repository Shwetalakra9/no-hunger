<!-- Bootstrap4 files-->
<link href="./vendor/css/bootstrap/bootstrap.css" rel="stylesheet" type="text/css"/>
<!-- <link href="./vendor/css/bootstrap/bootstrap-glyph.css" rel="stylesheet" type="text/css"/> -->

<!-- Font awesome 5 -->
<link href="./vendor/css/fontawesome/css/all.min.css" type="text/css" rel="stylesheet">

<!-- Animate -->
<link href="./vendor/css/animate/animate.css" type="text/css" rel="stylesheet">

<!-- custom icon lib -->
<link href="./resources/css/custom_icon_lib/fe.css" rel="stylesheet" type="text/css"/>
<!-- custom style -->
<link href="./resources/css/main.css" rel="stylesheet" type="text/css"/>
<link href="./resources/css/ui.css" rel="stylesheet" type="text/css"/>
<!-- <link href="./resources/css/responsive.css" rel="stylesheet" /> -->