<?php
//all global meta data, css and js that needs to run before page painting goes in
require_once './resources/templates/meta.php';//all global meta tages used in the site goes here
require_once './resources/templates/css.php';// all global css file goes in here
require_once './resources/templates/head-javascript.php';//all javacript that needs to run before page load