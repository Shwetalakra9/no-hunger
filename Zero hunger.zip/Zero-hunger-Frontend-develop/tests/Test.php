<?php

use PHPUnit\Framework\TestCase;

class Test extends TestCase
{
    /**
     * @test
     * @testdox
     */
    public function sampleTestCase()
    {
        $this->assertIsBool(true);
    }
}
